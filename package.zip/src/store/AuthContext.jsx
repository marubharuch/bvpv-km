import { createContext, useContext, useEffect, useState, useRef } from "react";
import { cache }   from "../lib/cache";
import { getUser } from "../db/userDb";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user,    setUser]    = useState(null);
  const [profile, setProfile] = useState(null);
  const [ready,   setReady]   = useState(false);
  const firebaseUserRef = useRef(null);

  const refreshUser = async () => {
    const firebaseUser = firebaseUserRef.current;
    if (!firebaseUser) return;
    try {
      const userData = await getUser(firebaseUser.uid, firebaseUser.email);
      const slim = buildSlimUser(firebaseUser, userData);
      setUser(slim);
      setProfile(userData);
      await cache.set("auth:user", slim);
      await cache.set(`auth:profile:${slim.uid}`, userData);
    } catch (e) {
      console.error("refreshUser error:", e);
    }
  };

  // Hydrate from cache immediately — no flash of unauthenticated UI
  useEffect(() => {
    (async () => {
      const cu = await cache.get("auth:user");
      const cp = cu ? await cache.get(`auth:profile:${cu.uid}`) : null;
      if (cu) { setUser(cu); if (cp) setProfile(cp); }
    })();
  }, []);

  // ✅ Firebase loaded lazily — SDK only downloads AFTER first render
  useEffect(() => {
    let unsub;

    (async () => {
      // Dynamic imports — not in initial JS bundle
      const [{ getAuth, onAuthStateChanged }] = await Promise.all([
        import("firebase/auth"),
      ]);

      const auth = getAuth(
        (await import("../lib/firebase")).getApp?.() ??
        (await import("firebase/app")).getApps()[0]
      );

      unsub = onAuthStateChanged(auth, async (firebaseUser) => {
        if (!firebaseUser) {
          setUser(null);
          setProfile(null);
          await cache.remove("auth:user");
          setReady(true);
          return;
        }

        try {
          // ✅ Use cached token — avoid unnecessary network round trip
          await firebaseUser.getIdToken(false);

          firebaseUserRef.current = firebaseUser;

          const userData = await getUser(firebaseUser.uid, firebaseUser.email);
          const slim = buildSlimUser(firebaseUser, userData);

          setUser(slim);
          setProfile(userData);
          await cache.set("auth:user", slim);
          await cache.set(`auth:profile:${slim.uid}`, userData);
        } catch (e) {
          console.error("onAuthStateChanged error:", e);
          setUser(null);
        } finally {
          setReady(true);
        }
      });
    })();

    return () => unsub?.();
  }, []);

  return (
    <AuthContext.Provider value={{ user, profile, ready, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);

// ── Helpers ────────────────────────────────────────────────────────

// ✅ Extracted helper — not re-created on every render
function buildSlimUser(firebaseUser, userData) {
  return {
    uid:           firebaseUser.uid,
    email:         firebaseUser.email,
    displayName:   userData.displayName || firebaseUser.displayName || null,
    photoURL:      firebaseUser.photoURL,
    emailVerified: firebaseUser.emailVerified,
    familyId:      userData.familyId    || null,
    role:          userData.role        || null,
    memberId:      userData.memberId    || null,
    mobile:        userData.mobile      || null,
    countryCode:   userData.countryCode || "+91",
  };
}