// submitFamilyRegistration — Optimized for minimum Firebase reads/writes

import { getDatabase, ref, push, get, update } from "firebase/database";
import { auth } from "../firebase";

/**
 * ✅ FIX: Generate unique 4-digit Family PIN using /familyPins index
 * Reads a single ~20-byte node instead of entire families tree.
 */
const generateFamilyPin = async (db) => {
  for (let i = 0; i < 10; i++) {
    const pin = Math.floor(1000 + Math.random() * 9000);
    const snap = await get(ref(db, `familyPins/${pin}`));
    if (!snap.exists()) return pin;
  }
  return Math.floor(1000 + Math.random() * 9000);
};

/**
 * MAIN FUNCTION
 * Creates new family and maintains all required indexes in a single multi-path write.
 */
export const submitFamilyRegistration = async (data) => {
  const db = getDatabase();
  const user = auth.currentUser;

  if (!user) throw new Error("User not authenticated");
  if (!data.city || !data.members?.length) throw new Error("City and members are required");

  try {
    // Generate Family ID and PIN
    const familyRef = push(ref(db, "families"));
    const familyId = familyRef.key;
    const familyPin = await generateFamilyPin(db);

    // Build members map
    const cleanMembers = {};
    const batchUpdates = {};

    data.members.forEach((m, i) => {
      const memberId = `m_${Date.now()}_${i}`;
      cleanMembers[memberId] = {
        name: m.name || "",
        mobile: m.mobile || "",
        isStudent: false,
        isHead: i === 0,
        relation: m.relation || (i === 0 ? "Head" : "Member"),
      };

      // ✅ Build /mobileIndex entries — enables O(1) phone lookup
      if (m.mobile) {
        const clean = m.mobile.replace(/\D/g, "").slice(-10);
        if (clean.length === 10) {
          batchUpdates[`mobileIndex/${clean}`] = { familyId, memberId };
        }
      }
    });

    const headMember = data.members[0];

    // ✅ Single multi-path update — one network round trip
    batchUpdates[`families/${familyId}`] = {
      city: data.city.trim(),
      native: data.native?.trim() || "",
      address: data.address?.trim() || "",
      members: cleanMembers,
      ownerUid: user.uid,
      familyPin,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    // User → family mapping
    batchUpdates[`users/${user.uid}`] = {
      familyId,
      name: user.displayName || "",
      email: user.email || "",
      joinedAt: Date.now(),
    };

    // ✅ /familyPins index — O(1) PIN lookup, replaces full families scan
    batchUpdates[`familyPins/${familyPin}`] = familyId;

    // ✅ /directory entry — lightweight node for phone/address directory pages
    batchUpdates[`directory/${familyId}`] = {
      headName: headMember?.name || "",
      mobile: headMember?.mobile || "",
      photoUrl: headMember?.photoUrl || "",
      city: data.city.trim(),
      native: data.native?.trim() || "",
      memberCount: data.members.length,
      pin: familyPin,
      updatedAt: Date.now(),
    };

    await update(ref(db), batchUpdates);

    return { familyId, familyPin, message: "Family registered successfully" };

  } catch (error) {
    console.error("Registration failed:", error);
    throw new Error("Failed to register family");
  }
};
