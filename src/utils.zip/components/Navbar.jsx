import { useContext, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ref, get } from "firebase/database";
import { db } from "../firebase";
import { AuthContext } from "../context/AuthContext";
import localforage from "localforage";

import { Home, LayoutDashboard, Info, User, LogIn } from "lucide-react";

export default function Navbar() {
  const { user } = useContext(AuthContext);

  const [registered, setRegistered] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadCachedStatus = async () => {
      if (!user?.uid) {
        setRegistered(false);
        setLoading(false);
        return;
      }

      const cacheKey = `registered_${user.uid}`;
      const cached = await localforage.getItem(cacheKey);

      if (cached !== null) {
        setRegistered(cached);
        setLoading(false);
      } else {
        const userSnap = await get(ref(db, `users/${user.uid}/familyId`));
        const hasFamily = userSnap.exists();

        setRegistered(hasFamily);
        setLoading(false);
        await localforage.setItem(cacheKey, hasFamily);
      }
    };

    loadCachedStatus();
  }, [user?.uid]);

  if (loading) return null;

  return (
    <nav className="flex justify-around items-center bg-white p-3 shadow text-sm">

      {/* 🏠 Home */}
      <Link to="/" className="flex flex-col items-center text-gray-700">
        <Home size={20} />
        <span>Home</span>
      </Link>

      {/* ℹ️ About */}
      <Link to="/about" className="flex flex-col items-center text-gray-700">
        <Info size={20} />
        <span>About</span>
      </Link>

      {/* 👨‍💻 Developer */}
      <Link to="/contact" className="flex flex-col items-center text-gray-700">
        <User size={20} />
        <span>Developer</span>
      </Link>

      {/* 🔄 Dynamic Last Button */}
      {!user?.uid ? (
        // 👤 Not logged in → Login
        <Link to="/login" className="flex flex-col items-center text-gray-700">
          <LogIn size={20} />
          <span>Login</span>
        </Link>
      ) : registered ? (
        // 📊 Logged in & registered → Dashboard
        <Link to="/dashboard" className="flex flex-col items-center text-gray-700">
          <LayoutDashboard size={20} />
          <span>Dashboard</span>
        </Link>
      ) : (
        // ⚠️ Logged in but not registered → Registration
        <Link to="/registration" className="flex flex-col items-center text-blue-600">
          <LayoutDashboard size={20} />
          <span>Register</span>
        </Link>
      )}

    </nav>
  );
}
