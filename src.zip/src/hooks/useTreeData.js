// hooks/useTreeData.js
// Single hook that manages the full tree lifecycle:
//   load → localForage (smartLoad) → edit/add → saveLocal → debounced sync

import { useState, useEffect, useCallback, useRef } from "react";
import {
  getMeta, saveLocalTree,
  editSelf, editAncestor, editDescendant, editSpouse, editSibling,
  addDescendant, addAncestor, addSibling, addSpouse,
} from "../utils/localTree";
import {
  smartLoad, pushToFirestore,
  scheduleSyncDebounced, registerOnlineSync, registerVisibilitySync,
} from "../utils/syncTree";

export function useTreeData(uid) {
  const [treeData,  setTreeData]  = useState(null);
  const [meta,      setMeta]      = useState({ isDirty:false, lastEditedAt:null, lastSyncedAt:null, version:0 });
  const [status,    setStatus]    = useState("idle");   // idle | loading | saving | syncing | error
  const [syncError, setSyncError] = useState(null);

  // ── Load on mount ───────────────────────────────────────────────────────────
  useEffect(() => {
    if (!uid) return;
    setStatus("loading");
    smartLoad(uid)
      .then(({ tree, source }) => {
        setTreeData(tree);
        setStatus("idle");
        console.log("🌳 Tree loaded from:", source);
        return getMeta(uid);
      })
      .then(setMeta)
      .catch(e => { setStatus("error"); console.error(e); });
  }, [uid]);

  // ── Register background sync listeners ─────────────────────────────────────
  useEffect(() => {
    if (!uid) return;
    const refreshMeta = () => getMeta(uid).then(setMeta);
    const unregOnline = registerOnlineSync(uid, refreshMeta);
    const unregVis    = registerVisibilitySync(uid, refreshMeta);
    return () => { unregOnline(); unregVis(); };
  }, [uid]);

  // ── Core: apply mutation + save local + schedule sync ──────────────────────
  const applyMutation = useCallback(async (mutFn) => {
    if (!treeData || !uid) return;
    setStatus("saving");
    try {
      const updated = mutFn(treeData);
      setTreeData(updated);
      const newMeta = await saveLocalTree(uid, updated);
      setMeta(newMeta);
      setStatus("idle");
      scheduleSyncDebounced(uid, 30_000);
    } catch (e) {
      setStatus("error");
      console.error("applyMutation failed:", e);
    }
  }, [treeData, uid]);

  // ── Edit actions ────────────────────────────────────────────────────────────
  const editMemberSelf = useCallback((data) =>
    applyMutation(t => editSelf(t, data)), [applyMutation]);

  const editMemberAncestor = useCallback((idx, data) =>
    applyMutation(t => editAncestor(t, idx, data)), [applyMutation]);

  const editMemberDescendant = useCallback((idx, data) =>
    applyMutation(t => editDescendant(t, idx, data)), [applyMutation]);

  const editMemberSpouse = useCallback((spouseKey, data) =>
    applyMutation(t => editSpouse(t, spouseKey, data)), [applyMutation]);

  const editMemberSibling = useCallback((sibKey, type, idx, data) =>
    applyMutation(t => editSibling(t, sibKey, type, idx, data)), [applyMutation]);

  // ── Add actions ─────────────────────────────────────────────────────────────
  const addMemberDescendant = useCallback((data) =>
    applyMutation(t => addDescendant(t, data)), [applyMutation]);

  const addMemberAncestor = useCallback((data) =>
    applyMutation(t => addAncestor(t, data)), [applyMutation]);

  const addMemberSibling = useCallback((sibKey, type, data) =>
    applyMutation(t => addSibling(t, sibKey, type, data)), [applyMutation]);

  const addMemberSpouse = useCallback((spouseKey, data) =>
    applyMutation(t => addSpouse(t, spouseKey, data)), [applyMutation]);

  // ── Manual sync ─────────────────────────────────────────────────────────────
  const syncNow = useCallback(async () => {
    if (!uid) return;
    setStatus("syncing");
    setSyncError(null);
    try {
      await pushToFirestore(uid);
      const newMeta = await getMeta(uid);
      setMeta(newMeta);
      setStatus("idle");
    } catch (e) {
      setStatus("error");
      setSyncError(e.message);
      console.error("Manual sync failed:", e);
    }
  }, [uid]);

  // ── Derived flags ───────────────────────────────────────────────────────────
  const isLoading  = status === "loading";
  const isSaving   = status === "saving";
  const isSyncing  = status === "syncing";
  const isOnline   = typeof navigator !== "undefined" ? navigator.onLine : true;

  return {
    // Data
    treeData,
    meta,

    // Status
    status,
    isLoading,
    isSaving,
    isSyncing,
    isOnline,
    syncError,

    // Edit
    editMemberSelf,
    editMemberAncestor,
    editMemberDescendant,
    editMemberSpouse,
    editMemberSibling,

    // Add
    addMemberDescendant,
    addMemberAncestor,
    addMemberSibling,
    addMemberSpouse,

    // Sync
    syncNow,
  };
}