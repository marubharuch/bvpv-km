// pages/VanshTreeView/components/LineageView.jsx
// Orchestrator: pulls treeData → builds rows → renders table.
// Keep this file thin — logic lives in buildLineageRows, UI in LineageTable.

import { buildLineageRows } from "../../../utils/buildLineageRows";
import LineageTable         from "./LineageTable";

export default function LineageView({ treeData }) {
  const { rows, spanMap, ancestors } = buildLineageRows(treeData);
  return <LineageTable rows={rows} spanMap={spanMap} ancestors={ancestors} />;
}