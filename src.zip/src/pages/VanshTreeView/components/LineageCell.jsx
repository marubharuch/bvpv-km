// components/LineageCell.jsx
// Reusable cell primitives for the Lineage Table view.

// ── TH — styled header cell ───────────────────────────────────────────────────
export function TH({ children }) {
  return (
    <th style={{
      padding:       "8px 12px",
      background:    "#5A1020",
      color:         "#F0D080",
      fontSize:      "0.58rem",
      fontFamily:    "'JetBrains Mono', monospace",
      fontWeight:    700,
      letterSpacing: "0.08em",
      textAlign:     "left",
      borderRight:   "1px solid rgba(240,208,128,0.15)",
      borderBottom:  "2px solid #C9A84C",
      whiteSpace:    "nowrap",
    }}>
      {children}
    </th>
  );
}

// ── TD style object — import and spread into <td style={{...tdStyle}} ─────────
export const tdStyle = {
  padding:       "8px 10px",
  borderRight:   "1px solid #f0e6e6",
  borderBottom:  "1px solid #f0e6e6",
  verticalAlign: "middle",
};

// ── Dash — empty cell placeholder ─────────────────────────────────────────────
export function Dash() {
  return (
    <span style={{ color:"#C0A0A0", fontSize:"0.75rem", fontFamily:"'JetBrains Mono',monospace" }}>
      —
    </span>
  );
}

// ── Cell — renders one person + optional spouse ───────────────────────────────
// data = { name, gender, spouse?: { name, gender }, isYou? } | null
export function Cell({ data, isYou }) {
  if (!data?.name) return <Dash />;

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:2 }}>

      {/* Person row */}
      <div style={{ display:"flex", alignItems:"center", gap:5 }}>
        <span style={{ fontSize:"0.82rem" }}>
          {data.gender === "F" ? "👩" : "👨"}
        </span>
        <span style={{
          fontFamily:  "'Playfair Display', serif",
          fontWeight:  isYou ? 700 : 600,
          color:       isYou ? "#5A1020" : "#7B1C2E",
          fontSize:    "0.8rem",
        }}>
          {data.name}
        </span>
        {isYou && (
          <span style={{
            fontSize:   "0.42rem",
            background: "#C9A84C",
            color:      "#fff",
            padding:    "1px 5px",
            borderRadius: 3,
            fontWeight: 700,
            fontFamily: "'JetBrains Mono', monospace",
          }}>
            YOU
          </span>
        )}
      </div>

      {/* Spouse row */}
      {data.spouse?.name && (
        <>
          <div style={{ height:1, background:"#f0d0d0", margin:"1px 4px" }} />
          <div style={{ display:"flex", alignItems:"center", gap:5 }}>
            <span style={{ fontSize:"0.72rem" }}>
              {data.spouse.gender === "F" ? "👩" : "👨"}
            </span>
            <span style={{
              fontFamily: "'Playfair Display', serif",
              fontStyle:  "italic",
              color:      "#9B2335",
              fontSize:   "0.72rem",
            }}>
              {data.spouse.name}
            </span>
          </div>
        </>
      )}
    </div>
  );
}