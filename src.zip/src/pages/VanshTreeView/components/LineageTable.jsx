// components/LineageTable.jsx
// Pure render component — receives pre-built rows + spanMap, renders the table.
// No data logic here. Import buildLineageRows separately.

import { Cell, TH, tdStyle } from "./LineageCell";

// Generates header label for any ancestor depth
const getAncHeader = (i) => {
  const labels = ["Father", "Grandfather", "Great-GF", "Great²-GF", "Great³-GF"];
  if (i < labels.length) return `${labels[i]} (anc_${i})`;
  return `Great${i - 1}×-GF (anc_${i})`;
};

export default function LineageTable({ rows, spanMap, ancestors }) {
  return (
    <div style={{ overflowX:"auto", padding:"16px 0 40px" }}>

      {/* Hint */}
      <div style={{ padding:"0 14px 10px", fontSize:"0.6rem", color:"#C0A0A0", fontFamily:"'JetBrains Mono',monospace" }}>
        📜 Lineage Table · cells merge vertically when value repeats
      </div>

      <table style={{ borderCollapse:"collapse", fontSize:"0.75rem", background:"#fff", minWidth:"max-content" }}>

        {/* ── Header ── */}
        <thead>
          <tr>
            <TH>Sr. No.</TH>
            <TH>Descendant / Child</TH>
            <TH>Self / Parent</TH>
            {ancestors.map((_, i) => (
              <TH key={i}>{getAncHeader(i)}</TH>
            ))}
          </tr>
        </thead>

        {/* ── Body ── */}
        <tbody>
          {rows.map((row, ri) => {
            const selfSpan = spanMap["self_" + ri];
            return (
              <tr key={ri} style={{ background: ri % 2 === 0 ? "#fff" : "#FDFAF5" }}>

                {/* Sr No */}
                <td style={{ ...tdStyle, color:"#C0A0A0", textAlign:"center", fontSize:"0.65rem", minWidth:40 }}>
                  {ri + 1}
                </td>

                {/* Descendant/Child — always individual per row */}
                <td style={{ ...tdStyle, minWidth:110 }}>
                  <Cell data={row.desc} />
                </td>

                {/* Self/Parent — merged vertically */}
                {selfSpan > 0 && (
                  <td rowSpan={selfSpan} style={{ ...tdStyle, minWidth:120, background: row.self?.isYou ? "#FDF6EC" : "inherit" }}>
                    <Cell data={row.self} isYou={row.self?.isYou} />
                  </td>
                )}

                {/* Ancestor columns — each merged independently */}
                {ancestors.map((_, i) => {
                  const span = spanMap["anc" + i + "_" + ri];
                  if (span === 0) return null; // merged above — skip
                  return (
                    <td key={i} rowSpan={span} style={{ ...tdStyle, minWidth:140 }}>
                      <Cell data={row.ancs[i]} />
                    </td>
                  );
                })}

              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}