// utils/localTree.js
// All localForage operations for vansh tree data + metadata.
// Never call Firestore directly — that's syncTree.js's job.

import localforage from "localforage";

// ── Keys ─────────────────────────────────────────────────────────────────────
const dataKey = (uid) => `vanshTree_${uid}`;
const metaKey = (uid) => `vanshMeta_${uid}`;

// ── Meta helpers ──────────────────────────────────────────────────────────────
export async function getMeta(uid) {
  return await localforage.getItem(metaKey(uid)) || {
    isDirty:      false,
    lastEditedAt: null,
    lastSyncedAt: null,
    version:      0,
  };
}

async function bumpMeta(uid) {
  const prev = await getMeta(uid);
  const next = {
    ...prev,
    isDirty:      true,
    lastEditedAt: Date.now(),
    version:      (prev.version || 0) + 1,
  };
  await localforage.setItem(metaKey(uid), next);
  return next;
}

export async function markSynced(uid) {
  const prev = await getMeta(uid);
  await localforage.setItem(metaKey(uid), {
    ...prev,
    isDirty:      false,
    lastSyncedAt: Date.now(),
  });
}

// ── Tree read/write ───────────────────────────────────────────────────────────
export async function getLocalTree(uid) {
  return await localforage.getItem(dataKey(uid));
}

export async function setLocalTree(uid, treeData) {
  await localforage.setItem(dataKey(uid), treeData);
}

// Save tree + bump metadata (use this for all user edits)
export async function saveLocalTree(uid, treeData) {
  await localforage.setItem(dataKey(uid), treeData);
  return await bumpMeta(uid);
}

// Save fresh data from Firestore (no dirty flag)
export async function cacheFromFirestore(uid, treeData) {
  await localforage.setItem(dataKey(uid), treeData);
  const prev = await getMeta(uid);
  await localforage.setItem(metaKey(uid), {
    ...prev,
    isDirty:      false,
    lastSyncedAt: Date.now(),
    version:      prev.version || 0,
  });
}

// ── Edit helpers — immutable tree mutations ───────────────────────────────────
// Each returns the full updated treeData (does NOT save — call saveLocalTree after)

// Edit self
export function editSelf(tree, data) {
  return { ...tree, self: { ...tree.self, ...data } };
}

// Edit ancestor at index
export function editAncestor(tree, idx, data) {
  const ancestors = [...(tree.ancestors || [])];
  ancestors[idx] = { ...ancestors[idx], ...data };
  return { ...tree, ancestors };
}

// Edit descendant at index
export function editDescendant(tree, idx, data) {
  const descendants = [...(tree.descendants || [])];
  descendants[idx] = { ...descendants[idx], ...data };
  return { ...tree, descendants };
}

// Edit spouse
export function editSpouse(tree, spouseKey, data) {
  return {
    ...tree,
    spouses: { ...tree.spouses, [spouseKey]: { ...(tree.spouses?.[spouseKey] || {}), ...data } },
  };
}

// Edit sibling
export function editSibling(tree, sibKey, type, idx, data) {
  // sibKey = "self" | "anc_0" | "desc_0"
  // type   = "elder" | "younger"
  const list = [...((tree.siblings?.[sibKey]?.[type]) || [])];
  list[idx] = { ...list[idx], ...data };
  return {
    ...tree,
    siblings: {
      ...tree.siblings,
      [sibKey]: { ...(tree.siblings?.[sibKey] || {}), [type]: list },
    },
  };
}

// ── Add helpers ───────────────────────────────────────────────────────────────

// Add descendant
export function addDescendant(tree, data) {
  const descendants = [...(tree.descendants || []).filter(d => d?.name), data];
  return { ...tree, descendants };
}

// Add ancestor above current top
export function addAncestor(tree, data) {
  const ancestors = [...(tree.ancestors || []).filter(a => a?.name), data];
  return { ...tree, ancestors };
}

// Add sibling
export function addSibling(tree, sibKey, type, data) {
  // type = "elder" | "younger"
  const existing = tree.siblings?.[sibKey]?.[type] || [];
  return {
    ...tree,
    siblings: {
      ...tree.siblings,
      [sibKey]: {
        ...(tree.siblings?.[sibKey] || {}),
        [type]: [...existing.filter(s => s?.name), data],
      },
    },
  };
}

// Add/update spouse
export function addSpouse(tree, spouseKey, data) {
  return {
    ...tree,
    spouses: { ...tree.spouses, [spouseKey]: data },
  };
}

// ── Clear local data ──────────────────────────────────────────────────────────
export async function clearLocalTree(uid) {
  await localforage.removeItem(dataKey(uid));
  await localforage.removeItem(metaKey(uid));
}