// utils/buildLineageRows.js
// Pure function — no JSX, no React.
// Takes treeData from Firestore and returns:
//   { rows, spanMap, ancestors }
//
// Row shape: { desc, self, ancs[] }
//   desc  = { name, gender, spouse? } | null   → Descendant/Child column
//   self  = { name, gender, spouse?, isYou? } | null → Self/Parent column
//   ancs  = ancestors.length items, each { name, gender, spouse? } | null
//
// spanMap shape: { "self_0": 4, "self_1": 0, "anc0_0": 6, ... }
//   value > 0 → render with rowSpan=value
//   value = 0 → skip (already merged above)

export function buildLineageRows(treeData) {
  const spouses  = treeData.spouses  || {};
  const siblings = treeData.siblings || {};

  // Filter out empty placeholder objects
  const ancestors = (treeData.ancestors  || []).filter(a => a?.name);
  const descs     = (treeData.descendants|| []).filter(d => d?.name);

  // ── Spouse helpers ──────────────────────────────────────────────────────────
  const ancSpouse  = (i) => { const s = spouses["anc_"  + i]; return s?.name ? s : null; };
  const selfSpouse =        spouses["self"]?.name ? spouses["self"] : null;
  const descSpouse = (i) => { const s = spouses["desc_" + i]; return s?.name ? s : null; };

  // ── Helper: full ancestor cells array ──────────────────────────────────────
  const fullAncs = () =>
    ancestors.map((a, i) => ({ name:a.name, gender:a.gender, spouse:ancSpouse(i) }));

  // ── Build rows ──────────────────────────────────────────────────────────────
  const rows = [];

  // A) Descendants + their siblings
  descs.forEach((d, di) => {
    const selfCell = { name:treeData.self?.name, gender:treeData.self?.gender, spouse:selfSpouse, isYou:true };

    // Descendant row
    rows.push({ desc:{ name:d.name, gender:d.gender, spouse:descSpouse(di) }, self:selfCell, ancs:fullAncs() });

    // Siblings of this descendant → also in Descendant col, same self+ancs
    [...(siblings["desc_"+di]?.elder  || []),
     ...(siblings["desc_"+di]?.younger|| [])]
      .filter(s => s?.name)
      .forEach(sib => {
        rows.push({ desc:{ name:sib.name, gender:sib.gender, spouse:null }, self:selfCell, ancs:fullAncs() });
      });
  });

  // B) No descendants — show YOU row
  if (descs.length === 0) {
    rows.push({
      desc: null,
      self: { name:treeData.self?.name, gender:treeData.self?.gender, spouse:selfSpouse, isYou:true },
      ancs: fullAncs(),
    });
  }

  // C) Siblings of YOU → Self/Parent col, same ancs
  [...(siblings["self"]?.elder  || []),
   ...(siblings["self"]?.younger|| [])]
    .filter(s => s?.name)
    .forEach(sib => {
      rows.push({ desc:null, self:{ name:sib.name, gender:sib.gender, spouse:null }, ancs:fullAncs() });
    });

  // D) Siblings of ancestors
  // Rule: sibling of anc_0 (father)    → Self/Parent col,  same ancs as YOU
  //       sibling of anc_i (i>0)       → ancs[i-1] col,    ancs[i+] filled, ancs[0..i-2] = null
  ancestors.forEach((_, ancIdx) => {
    [...(siblings["anc_"+ancIdx]?.elder  || []),
     ...(siblings["anc_"+ancIdx]?.younger|| [])]
      .filter(s => s?.name)
      .forEach(sib => {
        if (ancIdx === 0) {
          // Sibling of father → Self/Parent col
          rows.push({ desc:null, self:{ name:sib.name, gender:sib.gender, spouse:null }, ancs:fullAncs() });
        } else {
          // Sibling of anc_i → col i-1
          rows.push({
            desc: null,
            self: null,
            ancs: ancestors.map((_, i) => {
              if (i < ancIdx - 1)   return null;
              if (i === ancIdx - 1) return { name:sib.name, gender:sib.gender, spouse:null, isSib:true };
              return { name:ancestors[i].name, gender:ancestors[i].gender, spouse:ancSpouse(i) };
            }),
          });
        }
      });
  });

  // ── Compute rowSpan map ─────────────────────────────────────────────────────
  const spanMap = {};

  const computeSpans = (colKey, getName) => {
    let ri = 0;
    while (ri < rows.length) {
      const name = getName(rows[ri]);
      if (!name) { spanMap[colKey + "_" + ri] = 1; ri++; continue; }
      let span = 1;
      while (ri + span < rows.length && getName(rows[ri + span]) === name) span++;
      spanMap[colKey + "_" + ri] = span;
      for (let k = 1; k < span; k++) spanMap[colKey + "_" + (ri + k)] = 0;
      ri += span;
    }
  };

  computeSpans("self", r => r.self?.name || null);
  ancestors.forEach((_, i) => computeSpans("anc" + i, r => r.ancs[i]?.name || null));

  return { rows, spanMap, ancestors };
}