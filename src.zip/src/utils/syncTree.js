// utils/syncTree.js
// Handles all Firestore sync logic.
// Reads from localForage, writes to Firestore, updates metadata.

import { doc, setDoc, getDoc } from "firebase/firestore";
import { firestore }           from "../lib/firebase";
import {
  getLocalTree, getMeta, markSynced,
  cacheFromFirestore,
} from "./localTree";

const treeRef = (uid) => doc(firestore, "vanshTrees", uid);

// ── Push local → Firestore ────────────────────────────────────────────────────
export async function pushToFirestore(uid) {
  const tree = await getLocalTree(uid);
  if (!tree) throw new Error("No local tree to push");

  await setDoc(treeRef(uid), {
    ...tree,
    updatedAt: Date.now(),
  });

  await markSynced(uid);
  return true;
}

// ── Pull Firestore → local ────────────────────────────────────────────────────
export async function pullFromFirestore(uid) {
  const snap = await getDoc(treeRef(uid));
  if (!snap.exists()) return null;

  const data = snap.data();
  await cacheFromFirestore(uid, data);
  return data;
}

// ── Smart load on app start ───────────────────────────────────────────────────
// Decision logic:
//   1. No local data          → pull from Firestore
//   2. isDirty = true         → use local (user has unsaved changes), schedule sync
//   3. isDirty = false        → compare timestamps, use newer
export async function smartLoad(uid) {
  const [localTree, meta] = await Promise.all([
    getLocalTree(uid),
    getMeta(uid),
  ]);

  // No local data — fetch from Firestore
  if (!localTree) {
    const remote = await pullFromFirestore(uid);
    return { tree: remote, source: "firestore" };
  }

  // Has dirty local changes — use local, sync in background
  if (meta.isDirty) {
    return { tree: localTree, source: "local_dirty" };
  }

  // Compare timestamps
  try {
    const snap = await getDoc(treeRef(uid));
    if (!snap.exists()) return { tree: localTree, source: "local" };

    const remote     = snap.data();
    const remoteTime = remote.updatedAt || 0;
    const localTime  = meta.lastSyncedAt || 0;

    if (remoteTime > localTime) {
      // Firestore is newer — update local cache
      await cacheFromFirestore(uid, remote);
      return { tree: remote, source: "firestore_newer" };
    }

    return { tree: localTree, source: "local_fresh" };
  } catch (e) {
    // Offline — use local
    console.warn("syncTree: offline, using local data", e.message);
    return { tree: localTree, source: "local_offline" };
  }
}

// ── Auto sync with debounce ───────────────────────────────────────────────────
let syncTimer = null;

export function scheduleSyncDebounced(uid, delayMs = 30_000) {
  if (syncTimer) clearTimeout(syncTimer);
  syncTimer = setTimeout(async () => {
    if (!navigator.onLine) return;
    try {
      await pushToFirestore(uid);
      console.log("✅ Auto-synced to Firestore");
    } catch (e) {
      console.warn("⚠️ Auto-sync failed:", e.message);
    }
  }, delayMs);
}

// ── Online event sync ─────────────────────────────────────────────────────────
// Call once on app mount — syncs automatically when connection restored
export function registerOnlineSync(uid, onSynced) {
  const handler = async () => {
    const meta = await getMeta(uid);
    if (!meta.isDirty) return;
    try {
      await pushToFirestore(uid);
      console.log("✅ Online sync complete");
      onSynced?.();
    } catch (e) {
      console.warn("⚠️ Online sync failed:", e.message);
    }
  };
  window.addEventListener("online", handler);
  return () => window.removeEventListener("online", handler);
}

// ── Visibility sync ───────────────────────────────────────────────────────────
// Sync when user returns to tab
export function registerVisibilitySync(uid, onSynced) {
  const handler = async () => {
    if (document.visibilityState !== "visible") return;
    if (!navigator.onLine) return;
    const meta = await getMeta(uid);
    if (!meta.isDirty) return;
    try {
      await pushToFirestore(uid);
      onSynced?.();
    } catch (e) {
      console.warn("⚠️ Visibility sync failed:", e.message);
    }
  };
  document.addEventListener("visibilitychange", handler);
  return () => document.removeEventListener("visibilitychange", handler);
}